# Accounting Data Analysis with Python

## Overview
A beginner-friendly portfolio project that analyses a sample accounting transaction CSV. It calculates total income, total expenses and the net result, validates transaction data, and exports an expense-category breakdown.

**Data integrity note:** The included transactions are synthetic sample data. The results below are reproducible project outputs, not claimed client outcomes or proof of real-world savings.

## Skills demonstrated
- Python fundamentals (functions, loops, conditionals and exceptions)
- CSV file reading and writing
- Basic data validation and error handling
- Financial calculations
- Grouping expenses by category
- Generating summary reports

## Structure
- `analyze_transactions.py` — analysis script
- `data/sample_transactions.csv` — sample dataset
- `outputs/financial_summary.txt` — generated summary
- `outputs/category_summary.csv` — generated expense breakdown

## Run the project
Requires Python 3.9 or later. No external packages are required.

```bash
python analyze_transactions.py
```

## Verified output for the included dataset
- Transactions analysed: 12
- Total income: PKR 374,000.00
- Total expenses: PKR 61,600.00
- Net result: PKR 312,400.00

Run the script yourself to reproduce the results.

## Portfolio description
**Accounting Data Analysis with Python:** Created a Python script to validate transaction records from a CSV, calculate total income, expenses and net result, and export an expense-category report. Tested it against a 12-row synthetic dataset and verified the output totals. Demonstrates beginner-level Python, data handling and basic financial analysis.

## GitHub publishing steps
1. Create a repository called `accounting-data-analysis-python`.
2. Upload the files while preserving the folder structure.
3. Use this repository description: `Python project to analyse sample accounting transactions and generate a financial summary.`
4. Run the script and optionally add a screenshot of the output.
5. Pin the repository to your GitHub profile.

## Limitations
This is a learning project, not a full accounting system. It does not demonstrate bank reconciliation, tax compliance, audit assurance or production software development.
