import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT_FILE = ROOT / "data" / "sample_transactions.csv"
OUTPUT_DIR = ROOT / "outputs"

def load_transactions(path):
    transactions = []
    with path.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        required = {"date", "description", "type", "amount_pkr"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV is missing one or more required columns.")
        for line_number, row in enumerate(reader, start=2):
            try:
                amount = float(row["amount_pkr"])
            except (TypeError, ValueError):
                raise ValueError(f"Invalid amount on CSV line {line_number}.")
            kind = row["type"].strip().title()
            if kind not in {"Income", "Expense"} or amount < 0:
                raise ValueError(f"Invalid transaction on CSV line {line_number}.")
            transactions.append({
                "date": row["date"].strip(),
                "description": row["description"].strip(),
                "type": kind,
                "amount": amount,
            })
    return transactions

def analyse(transactions):
    income = sum(t["amount"] for t in transactions if t["type"] == "Income")
    expenses = sum(t["amount"] for t in transactions if t["type"] == "Expense")
    categories = defaultdict(float)
    for t in transactions:
        if t["type"] == "Expense":
            categories[t["description"]] += t["amount"]
    return income, expenses, income - expenses, categories

def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    transactions = load_transactions(INPUT_FILE)
    income, expenses, net, categories = analyse(transactions)
    summary = (
        "SAMPLE MONTHLY FINANCIAL SUMMARY (PKR)\n"
        "==========================================\n"
        f"Transactions analysed: {len(transactions)}\n"
        f"Total income:          PKR {income:,.2f}\n"
        f"Total expenses:        PKR {expenses:,.2f}\n"
        f"Net result:            PKR {net:,.2f}\n"
        "Note: Synthetic demonstration data, not real client data.\n"
    )
    (OUTPUT_DIR / "financial_summary.txt").write_text(summary, encoding="utf-8")
    with (OUTPUT_DIR / "category_summary.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["expense_category", "total_pkr"])
        for category, amount in sorted(categories.items()):
            writer.writerow([category, f"{amount:.2f}"])
    print(summary)
    print("Expense-category report saved to outputs/category_summary.csv")

if __name__ == "__main__":
    main()
